/**
 * platform name
 */
const platform = "minecraft";

/**
 * minecraft color code to rgb/text-decoration/font-style
 */
const mcolor = {
    "§0": "color: rgb(0,0,0);",
    "§1": "color: rgb(0,0,42);",
    "§2": "color: rgb(0,42,0);",
    "§3": "color: rgb(0,42,42);",
    "§4": "color: rgb(42,0,0);",
    "§5": "color: rgb(42,0,42);",
    "§6": "color: rgb(42,42,0);",
    "§7": "color: rgb(42,42,42);",
    "§8": "color: rgb(21,21,21);",
    "§9": "color: rgb(21,21,63);",
    "§a": "color: rgb(21,63,21);",
    "§b": "color: rgb(21,63,63);",
    "§c": "color: rgb(63,21,21);",
    "§d": "color: rgb(63,21,63);",
    "§e": "color: rgb(63,63,21);",
    "§f": "color: rgb(63,63,63);",
    "§g": "color: rgb(55,53,1);",
    "§k": "text-decoration: underline underline line-through;",
    "§l": "font-weight: bold;",
    "§m": "text-decoration: line-through;",
    "§n": "text-decoration: underline;",
    "§o": "font-style: italic;",
    "§r": "font-style: normal; font-weight: normal; color: ver(--main_color);text-decoration: none;",
}

/**
 * funtion of asking online player infomartion
 * オンラインプレイヤーの情報を問い合わせる関数
 * @param {*} conn rcon object
 * @param {*} plist list of players  オンラインのプレイヤーの配列 array
 * @param {*} flg icon mode flag アイコンモードのオンオフ boolean
 * @returns plist new list of players 新しいプレイヤーリスト
 */
async function getPlayerList(conn, plist, flg) {

    let status = await conn.execute('craftcontrolrcon players');

    try {


        let plist_sub = JSON.parse(status.toString()).players;

        let count = plist_sub.length;

        if (count > 0) {
            //1人以上いた場合
            for (let i = 0; i < plist_sub.length; i++) {
                //もし手元のリストに情報がなければ，登録
                if (plist.some(item => item.uid === plist_sub[i].uuid) == false) {
                    var color = ('000000' + Math.floor(Math.random() * 16777215).toString(16)).slice(-6);
                    var avatar = "";
                    var steamname = "";
                    plist.push({
                        name: plist_sub[i].name,
                        uid: plist_sub[i].uuid,
                        avatar: avatar,
                        exists: true,
                        color: color,
                        health: Math.round(plist_sub[i].health * 2) / 2,
                        level: plist_sub[i].level,
                    });

                } else {
                    plist.find(item => item.uid === plist_sub[i].uuid).exists = true;
                    plist.find(item => item.uid === plist_sub[i].uuid).health = Math.round(plist_sub[i].health * 2) / 2;
                    plist.find(item => item.uid === plist_sub[i].uuid).level = plist_sub[i].level;

                }

            }
            if (flg == true) {
                //アイコンモード　オンの時
                for (var i = 0; i < plist.length; i++) {

                    if (plist[i].avatar == "" && plist[i].uid) {
                        //スキン情報が空なら，問い合わせ
                        let q = i;
                        try {

                            fetch("https://sessionserver.mojang.com/session/minecraft/profile/" + plist[q].uid)
                                .then(res => res.text())
                                .then(body => {
                                    let base64 = JSON.parse(body).properties[0].value;

                                    let pl = JSON.parse(Buffer.from(base64, 'base64').toString('ascii'));

                                    plist[q].avatar = pl.textures.SKIN.url;

                                })
                                .catch((e) => {

                                    console.log(e);
                                });

                        } catch (e) {
                            console.log(e);
                        }

                    }

                }
            }

        }

    } catch (e) {

        console.log(e);
    }

    return plist;

}

/**
 * 最新のログ行数を確保しておく
 * ログはこの行数以降で追加されたものを取得する
 */
let linenumber = 10000;

/**
 * Get log funtion ログ問い合わせ関数
 * @param {*} conn rcon object
 * @returns t_log log text string or array 文字列または配列のログデータ
 */
async function getLog(conn) {

    let t_log;
    let t_list = new Array();
    t_list = [];
    let status;

    try {
        status = await conn.execute('craftcontrolrcon console ' + linenumber);
        //ここでCraftcontrolrconプラグインのコマンドを発している
        //サーバーのログファイルから最新のログを読んでいる
        let data = JSON.parse(status.toString());
        linenumber = data.lineNumber;
        if (Array.isArray(data)) { t_log = new Array(); t_log = []; }
        for (let i = 0; i < data.messages.length; i++) {
            t_list.push(data.messages[i]);
        }
        if (t_list.length > 0) t_log = t_list;

    } catch (e) {
        console.log(e);

        t_log = "it can not get any logs.";

    }
    return t_log;
}

/**
 * funtion to format logs ログ整形関数　文字列を正規表現をつかってゴリゴリのゴリで文字装飾もやってしまうやつ
 * @param {*} data log data string ログ文字列
 * @param {*} date_format date format string (see config.json. ex. yyyy/MM/dd hh:mm ) 日時フォーマット
 * @param {*} plist list of players for decorating logs ログ装飾で使うためのプレイヤーリスト
 * @returns data formatted log string 整形済ログ文字列
 */
async function getFormattedLog(data, date_format, plist = null) {

    //Spig サーバーではPingモードをオンにするとサーバーで以下のログを吐き出し続けるので、 該当する場合はスキップする
    if (!data.match(/Rcon issued server command: \/ping/)) {
        let header = "";
        let match = null;
        let time = "";

        //情報の種類は，chat, info, warn, error, otherの５つに分類する
        let detail = "other";

        //時間表示を整形
        match = data.match(/\[([0-9]{2}):([0-9]{2}):([0-9]{2})\]/);
        if (match) {
            let tmp = new Date();
            let utime = new Date(tmp.getFullYear(), tmp.getMonth(), tmp.getDate(), Number(match[1]), Number(match[2]), Number(match[3]));
            time = getFormattedDate(utime, date_format);
            header = time;
            data = data.replace(/\[([0-9]{2}):([0-9]{2}):([0-9]{2})\]/, "");
        }

        //情報の種類を特定
        match = data.match(/\[(.)*\]:/);
        if (match) {
            if (match[0].match(/\[Async Chat Thread/)) {

                let matchp = data.match(/\<(.)*\>/);

                if (matchp) {
                    let player_name = matchp[0].replace("<", "").replace(">", "");
                    data = data.replace(matchp[0], player_name);
                }

                detail = "chat";
            } else if (match[0].match(/INFO\]:/)) {
                detail = "info";
            } else if (match[0].match(/WARN\]:/)) {
                detail = "warn";
            } else if (match[0].match(/ERROR\]:/)) {
                detail = "error";
            }
            data = data.replace(match[0], "");
            header = `<span class= "log_date" > ` + header + ` <span style = "background-color: var(--log_` + detail + `_color); border-radius: 0.5em; padding: 0 0.5em;" > ` + detail + "</span></span><br>";
        }

        //カラーコードはすべて置き換える　mcolor{}
        match = data.match(/§([0-9]|[a-z]){1}/g);
        if (match) {

            for (let i = 0; i < match.length; i++) {
                data = data.replace(match[i], `<span style="` + mcolor[match[i]] + `">`) + `</span>`;
            }

        }

        if (plist) {
            for (let i = 0; i < plist.length; i++) {
                let pi = data.match(plist[i].name);
                if (pi) {
                    let reg = new RegExp('<' + pi[0] + '>');
                    data = data.replace(reg, pi[0]);
                    data = data.replace(pi[0], `<span class="p_info" style="background-color: ` + hex2rgba("#" + plist[i].color, .5) + `;">` + plist[i].name + `</span>`);
                }
            }
        }

        data = `<div class= "log_` + detail + `" >` + header + "<span>" + data + "</span> </div>";
        return data;

    }
}

/**
 * template of iconmode avatar part
 * アイコンモードのアバター表示部分のテンプレート関数
 * レンダリング側から呼び出される
 * アイコンモードの島の形式はレンダリング側で決めている
 * @param {*} player player information array
 * interface pObj {
 *  name: string;
 *  uid: string;
 *  steamid?: string;
 *  avatar: string;
 *  steamname?: string;
 *  exists: boolean;
 *  color: string;
 *  health?: number;
 *  level?: number;
 *  model?: string;
 * }
 * @returns 
 */
async function AvatarTemplate(player) {
    let img = `<img style="
    width: 384px;
    position: absolute;
    clip: rect(48px 96px 96px 48px);

    margin-left: -48px;
    margin-top: -48px;
    top: 0px;
    left: 0px;

    image-rendering: pixelated;
    " src="` + player.avatar + `">`;
    return img;
}


/**
 * temnplate of iconmode right under part
 * アイコンモードのアバター表示部分のテンプレート関数
 * レンダリング側から呼び出される
 * アイコンモードの島の形式はレンダリング側で決めている
 * @param {*} player player information array
 * interface pObj {
 *  name: string;
 *  uid: string;
 *  steamid?: string;
 *  avatar: string;
 *  steamname?: string;
 *  exists: boolean;
 *  color: string;
 *  health?: number;
 *  level?: number;
 *  model?: string;
 * } 
 * @returns 
 */
async function SnameTemplate(player) {
    let sname = "Lv." + player.level + " HP" + player.health;
    return sname;
}

/**
 * hex2rgba function カラーコード変換のための内部関数
 * @param {*} hex from #000000 to #ffffff or #000 to #fff
 * @param {*} alpha alpha value from 0 to 1
 * @returns rgba(r,g,b,a) string
 */
function hex2rgba(hex, alpha = 1) {

    // ロングカラーコード
    let r = hex.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i)
    let c = null
    if (r) {
        c = r.slice(1, 4).map(function (x) { return parseInt(x, 16) })
    }
    // ショートカラーコード
    r = hex.match(/^#([0-9a-f])([0-9a-f])([0-9a-f])$/i)
    if (r) {
        c = r.slice(1, 4).map(function (x) { return 0x11 * parseInt(x, 16) })
    }
    // 該当しない場合はnull
    if (!c) {
        return null
    }
    return `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${alpha})`
}

/**
 * Date format function 日時整形関数　内部関数
 * @param {*} date unix time
 * @param {*} format format
 * @returns formatted date string
 */
const getFormattedDate = (date, format) => {
    const symbol = {
        M: date.getMonth() + 1,
        d: date.getDate(),
        h: date.getHours(),
        m: date.getMinutes(),
        s: date.getSeconds(),
    };

    const formatted = format.replace(/(M+|d+|h+|m+|s+)/g, (v) =>
        ((v.length > 1 ? "0" : "") + symbol[v.slice(-1)]).slice(-2));

    return formatted.replace(/(y+)/g, (v) =>
        date.getFullYear().toString().slice(-v.length)
    );
};

module.exports = { platform, getPlayerList, getLog, getFormattedLog, AvatarTemplate, SnameTemplate };
const platform = "palworld";

async function getPlayerList(conn, plist, flg) {
    let status = await conn.execute('showplayers');
    let data = status.toString();

    let plist_sub = data.split('\n');
    plist_sub.splice(0, 1);
    //ヘッダーいらない
    plist_sub.pop();
    //末尾は空行になるからいらない
    //パルワールドが返してくる情報はとても扱いづらい。もっとユーザーフレンドリーな形式で返してほしい
    let count = plist_sub.length;

    if (count > 0) {
        for (let i = 0; i < count; i++) {
            var avatar = "";
            var steamname = "";

            if (plist.some(item => item.uid === plist_sub[i].split(",")[1]) == false) {
                var color = ('000000' + Math.floor(Math.random() * 16777215).toString(16)).slice(-6);

                plist.push({
                    name: plist_sub[i].split(",")[0],
                    uid: plist_sub[i].split(",")[1],
                    steamid: plist_sub[i].split(",")[2],
                    avatar: avatar,
                    steamname: steamname,
                    exists: true,
                    color: color,
                });
            } else {
                plist.find(item => item.uid === plist_sub[i].split(",")[1]).exists = true;
                //もしリストにいれば，存在フラグをtrueにする
                //flg onでsteam name　がなければ問い合わせ

            }
        }

        if (flg == true) {
            for (var i = 0; i < plist.length; i++) {

                if (plist[i].steamname == "" && plist[i].steamid) {
                    //steamnameが空なら，問い合わせ
                    let q = i;
                    try {

                        fetch("https://steamcommunity.com/profiles/" + plist[q].steamid + "/?xml=1")
                            .then(res => res.text())
                            .then(body => XMLparser.parse(body))
                            .then(json => {

                                plist[q].avatar = json.profile.avatarMedium;
                                plist[q].steamname = json.profile.steamID;

                            })
                            .catch((e) => {

                                console.log(e);
                            });

                    } catch (e) {
                        console.log(e);
                    }

                }

            }
        }
    }
    return plist;

}

async function getLog(conn) {
    return "";
}

async function getFormattedLog(data, date_format, plist = null) {
    //パルワールドはサーバーログを読む機能がないので、なにもしないで返す
    return data;
}

async function AvatarTemplate(data) {
    let img = `<img src="` + data.avatar + `" style="width: 48px;">`;
    return img;
}

async function SnameTemplate(data) {
    let sname = data.steamname;
    return sname;
}

module.exports = { platform, getPlayerList, getLog, getFormattedLog, AvatarTemplate, SnameTemplate };